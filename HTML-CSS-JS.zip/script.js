const score = document.querySelector('.score');
const startScreen = document.querySelector('.startScreen');
const gameArea = document.querySelector('.gameArea');

startScreen.addEventListener('click', initializeGame);

let player = { speed: 5, score: 0 }; // Starting speed is always 5

let keys = { ArrowUp: false, ArrowDown: false, ArrowLeft: false, ArrowRight: false };

document.addEventListener('keydown', keyDown);
document.addEventListener('keyup', keyUp);

function keyDown(e) {
  e.preventDefault();
  keys[e.key] = true;
}

function keyUp(e) {
  e.preventDefault();
  keys[e.key] = false;
}

function isCollide(a, b) {
  aRect = a.getBoundingClientRect();
  bRect = b.getBoundingClientRect();

  return !((aRect.bottom < bRect.top) ||
    (aRect.top > bRect.bottom) ||
    (aRect.right < bRect.left) ||
    (aRect.left > bRect.right));
}

function moveLines() {
  let lines = document.querySelectorAll('.lines');
  lines.forEach(function (item) {
    if (item.y >= 700) {
      item.y -= 750;
    }
    item.y += player.speed;
    item.style.top = item.y + "px";
  });
}

function endGame() {
  player.start = false;
  startScreen.classList.remove('hide');
  startScreen.innerHTML = "Game over <br> Your final score is " + player.score +
    " <br> press here to restart the game.";
}

function moveEnemy(myCar) {
  let enemyCarList = document.querySelectorAll('.enemyCar');
  enemyCarList.forEach(function (enemyCar) {
    if (isCollide(myCar, enemyCar)) {
      endGame();
    }

    if (enemyCar.y >= 750) {
      enemyCar.y = -300;
      enemyCar.style.left = Math.floor(Math.random() * 350) + "px";
    }

    enemyCar.y += player.speed;
    enemyCar.style.top = enemyCar.y + "px";
  });
}

let speedUpInterval; // To store the interval ID for speed increase

function runGame() {
  let car = document.querySelector('.myCar');
  let road = gameArea.getBoundingClientRect();

  if (player.start) {
    moveLines();
    moveEnemy(car);

    if (keys.ArrowUp && player.y > (road.top + 150)) { player.y -= player.speed }
    if (keys.ArrowDown && player.y < (road.bottom - 85)) { player.y += player.speed }
    if (keys.ArrowLeft && player.x > 0) { player.x -= player.speed }
    if (keys.ArrowRight && player.x < (road.width - 50)) { player.x += player.speed }

    car.style.top = player.y + "px";
    car.style.left = player.x + "px";

    window.requestAnimationFrame(runGame);

    // Check for passing enemy cars
    let enemyCarList = document.querySelectorAll('.enemyCar');
    enemyCarList.forEach(function (enemyCar) {
      //Check if the car has been passed before 
      if (!enemyCar.dataset.passed) {
        // Get the Y-coordinates of the rear ends
        const myCarRearY = player.y + car.offsetHeight;
        const enemyCarRearY = enemyCar.offsetTop + enemyCar.offsetHeight;

        // Check if te player car has passed the enemy car
        if (myCarRearY.y> enemyCarRearY) {
          player.score+= 10; //Increment score by 10
          score.innerHTML = "Score: " + player.score + "\nspeed: " + player.speed;
          enemyCar.dataset.passed = true; // Mark the car as passed
        }
      }
    });
//Update score display
    player.score++;
    score.innerText = "Score: " + player.score + "\nSpeed: " + player.speed;

    // Speed up after every 5 seconds
    speedUpInterval = setInterval(() => {
      player.speed += 0.005; // Increase the speed by 0.005;
      console.log("Speed increased to: 5", player.speed); // Optional for debugging
    }, 5000); // 5000 milliseconds = 5 seconds
  }
}

function initializeGame() {
  startScreen.classList.add('hide');
  gameArea.innerHTML = "";

  player.start = true;
  player.score = 0;
  player.speed = 5; // Reset speed to 5 on game restart
  window.requestAnimationFrame(runGame);

  // Clear the interval if it's running (prevents multiple speed increases)
  clearInterval(speedUpInterval);

  for (x = 0; x < 5; x++) {
    let roadLine = document.createElement('div');
    roadLine.setAttribute('class', 'lines');
    roadLine.y = (x * 150);
    roadLine.style.top = roadLine.y + "px";
    gameArea.appendChild(roadLine);
  }

  let car = document.createElement('div');
  car.setAttribute('class', 'myCar');
  gameArea.appendChild(car);

  player.x = car.offsetLeft;
  player.y = car.offsetTop;

  for (x = 0; x < 3; x++) {
    let enemyCar = document.createElement('div');
    enemyCar.setAttribute('class', 'enemyCar');
    enemyCar.y = ((x + 1) * 350) * -1;
    enemyCar.style.top = enemyCar.y + "px";
    enemyCar.style.left = Math.floor(Math.random() * 350) + "px";
    gameArea.appendChild(enemyCar);
  }
}